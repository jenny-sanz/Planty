<?php
if(!defined('ABSPATH')){exit;}return['handle'=>'elementor-packages-documents','deps'=>['elementor-packages-store','elementor-packages-v1-adapters','react',],];