<?php


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>
<!-- coder mon footer  -->
<footer class="mon-footer">
	<p>
		<a href="">Mentions légales</a>
	</p>
</footer>
<?php wp_footer(); ?>

</body>
</html>

